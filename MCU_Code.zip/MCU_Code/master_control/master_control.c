//Some areas of this program, in particular the I2C code, is adapted from an
//example provided by TI. As such we have included their copyright notice.
//#############################################################################
// $TI Release: F2837xD Support Library v3.11.00.00 $
// $Release Date: Sun Oct  4 15:55:24 IST 2020 $
// $Copyright:
// Copyright (C) 2013-2020 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"

//
// Defines
//
#define SLAVE_ADDRESS               0x00
#define Si570_ADDR                  0x55
#define SYNTH_MCP_ADDR              0x20
#define DBL_MCP_ADDR                0x24
#define AMP_MCP_ADDR                0x25
#define ATT1_MCP_ADDR               0x27
#define ATT2_MCP_ADDR               0x23
#define FILT1_MCP_ADDR              0x22
#define FILT2_MCP_ADDR              0x21
#define FILT3_MCP_ADDR              0x26
#define MCP_IODIR                   0x00
#define MCP_OLAT                    0x0A
#define LCD_ADDR                    0x72
#define EEPROM_HIGH_ADDR            0x00
#define EEPROM_LOW_ADDR             0x30
#define NUM_BYTES                   8
#define MAX_BUFFER_SIZE             14      // Max is currently 14 because of
                                            // 2 address bytes and the 16-byte 
                                            // FIFO

//
// I2C message states for I2CMsg struct
//
#define MSG_STATUS_INACTIVE         0x0000 // Message not in use, do not send
#define MSG_STATUS_SEND_WITHSTOP    0x0010 // Send message with stop bit
#define MSG_STATUS_WRITE_BUSY       0x0011 // Message sent, wait for stop
#define MSG_STATUS_SEND_NOSTOP      0x0020 // Send message without stop bit
#define MSG_STATUS_SEND_NOSTOP_BUSY 0x0021 // Message sent, wait for ARDY
#define MSG_STATUS_RESTART          0x0022 // Ready to become master-receiver
#define MSG_STATUS_READ_BUSY        0x0023 // Wait for stop before reading data

//
// Error messages for read and write functions
//
#define ERROR_BUS_BUSY              0x1000
#define ERROR_STOP_NOT_READY        0x5555
#define SUCCESS                     0x0000

//
// Typedefs
//
struct I2CMsg 
{
    uint16_t msgStatus;                  // Word stating what state msg is in.
                                         // See MSG_STATUS_* defines above.
    uint16_t slaveAddr;                  // Slave address tied to the message.
    uint16_t numBytes;                   // Number of valid bytes in message.
    uint16_t msgBuffer[MAX_BUFFER_SIZE]; // Array holding message data.
};

//
// Global Variables
//
struct I2CMsg i2cMsgOut = {MSG_STATUS_INACTIVE,
                           SLAVE_ADDRESS,
                           NUM_BYTES,
                           0x00,                // Message bytes
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00};
struct I2CMsg i2cMsgIn  = {MSG_STATUS_INACTIVE,
                           SLAVE_ADDRESS,
                           NUM_BYTES,
                           0x00,                // Message bytes
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00,
                           0x00};


struct I2CMsg *currentMsgPtr;                   // Used in interrupt
bool I2CB = false;

//MCP23008 output states
//Synthesizer MCP device
int synth_LF = 0x19; //"0001 1001" (switches to 1-10MHz) Freq sel 1 off, Vc off, 571 on, Divider on
int synth_HF = 0x0A; //"0000 1010" (switches to 10-125MHz) Freq sel 1 on, Vc off, 571 on, Divider off
//Doubler MCP device
int dbl_LF = 0x08; //"0000 1000" (switches to 1-125MHz) Amp power off, Freq sel 6, 5, 4 low, Freq sel 7 high
int dbl_HF = 0x13; //"0001 0011" (switches to 125-250MHz) First Amp power on,Freq sel 6, 7 low, freq sel 4, 5 high
int dbl_VHF = 0x34; //"0011 0100" (switches to 250-500MHz) Both Amp power on,Freq sel 7, 5, 4 low, freq sel 6 high
//Amplifier MCP device
int amp_FB1 = 0x01;
int amp_FB2 = 0x02;
int amp_FB3 = 0x04;

//Si570 Registers
uint8_t allRegs[20];
long HS_DIV;
long N1;
long long RFREQ;
//Si570 variables
long Frequency;
long offsetFreq = 15; //offset necessary at 10MHz
long VFOBase;
long Fxtal;
long Fout;
long long Fdco;
double r;

//Numpad Variables
int rowNum;
int colNum;
int coltest;
int numInput;
char numChar;
bool newInput = false;

//Menu Variables
int state = 0;
int mode = 0;
int tempcol = 0;
int inputFreq[10];
int inputPower[10];
int inputData[10];
long freq = 100000000;
int power = 0;
char stringFreq[10];
char stringPower[10];

//Calibration Table: subtracts this 'int' from the attenuation applied to the input of the attenuator
int cal; //variable to index the calTable and fineCalTable
int calTable[150];

//Fine calibration table: activates 0.5dB attenuator on a '1' and deactivates on a '0'
int fineCalTable[150];


//
//Debug
//
int pin22;
int test;
int count = 0;


//
// Function Prototypes
//
void setupLaunchPad();
void initI2C(void);
void setupCal();
long calFreq(long freq);
void clearLCD();
void setLCD(int row, int col, char *text);
void setLCDChar(int row, int col, char c);
void setLCD(int row, int col, char *text);
void read570Regs();
void setupMCP();
void setMCP(char address, char config);
void setPower(int power, long freq);
void setupSi570();
void writeSi570Reg(int reg, int val);
void setCoarseFrequency(long f);
void set570Regs(int hsdiv, long n1, long long rfreq);
uint16_t readData(struct I2CMsg *msg);
uint16_t writeDataA(struct I2CMsg *msg);
uint16_t writeDataB(struct I2CMsg *msg);
void sendIt();
void readIt();
void numpadInterruptHandler(void);
__interrupt void XINT1Handler(void);
__interrupt void XINT2Handler(void);
__interrupt void XINT3Handler(void);
__interrupt void XINT4Handler(void);

__interrupt void i2cAISR(void);

//
// Main
//
void main(void)
 {
    //Create the calibration tables
    setupCal();

    //Set up pins, I2C and interrupts
    setupLaunchPad();

    //Set up MCP units
    setupMCP();

    //Set up Si570
    setupSi570();
    setCoarseFrequency(freq);

    //Set up power
    setPower(power, freq);

    //Set up LCD screen
    clearLCD();
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    //Increase Brightness red
    i2cMsgOut.slaveAddr = LCD_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = '|'; //Puts LCD screen into settings mode " | "
    i2cMsgOut.msgBuffer[1] = 128+29;
    sendIt();
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    //Increase Brightness green
    i2cMsgOut.slaveAddr = LCD_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = '|'; //Puts LCD screen into settings mode " | "
    i2cMsgOut.msgBuffer[1] = 158+29;
    sendIt();
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    //Increase Brightness blue
    i2cMsgOut.slaveAddr = LCD_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = '|'; //Puts LCD screen into settings mode " | "
    i2cMsgOut.msgBuffer[1] = 188+29;
    sendIt();

    setLCD(1,0,"1. Standard");
    setLCD(2,0,"2. AM");
    setLCD(3,0,"3. FM");
    setLCD(4,0,"4. IQ");

    //Debug Loop
//    while(1){
//        setPower(0);
//        DEVICE_DELAY_US(500000);
//        setPower(-5);
//        DEVICE_DELAY_US(500000);
//        setPower(-10);
//        DEVICE_DELAY_US(500000);
//    }


    // Loop indefinitely
    while(1)
    {
        switch(state){
            //Mode Menu
            case 0:
            {
                clearLCD();
                setLCD(1,0,"1. Standard");
                setLCD(2,0,"2. AM");
                setLCD(3,0,"3. FM");
                setLCD(4,0,"4. IQ");
                while(state == 0){
                    if(newInput){
                        if(numInput == 1){
                            state = 1;
                            mode = 1;
                        }

                        if(numInput == 2){
                            state = 1;
                            mode = 2;
                        }

                        if(numInput == 3){
                            state = 1;
                            mode = 3;
                        }

                        if(numInput == 4){
                            state = 1;
                            mode = 4;
                        }
                        newInput = false;
                    }
                }

            }
            break;

            //Standard Display
            case 1:
            {
                int dataBinary[20];
                int i;
                for(i=0; i<20; i++){
                    dataBinary[i] = 0;
                }
                clearLCD();
                setLCD(1,0,"1.Freq: ");
                setLCD(1,8,stringFreq);
                setLCD(1,18,"Hz");
                setLCD(2,0,"2.Power: ");
                if(power<0){
                    setLCD(2,9,"-");
                }
                if(power>0){
                    setLCD(2,9,"+");
                }
                setLCD(2,10,stringPower);
                setLCD(2,17,"dBm");
                if(mode == 1){
                    setLCD(4,0,"Mode: SINE");
                    setCoarseFrequency(freq);
                    setPower(power, freq);
                }
                if(mode == 2){
                    setLCD(4,0,"Mode: AM");
                    setCoarseFrequency(freq);
                    setPower(power, freq);
                    int k = 0;
                    for(i=3;i>=0; i--){
                        dataBinary[k] = (inputData[0]>>i) & 0x01;
                        dataBinary[k+4] = (inputData[1]>>i) & 0x01;
                        k++;
                    }
                }
                if(mode == 3){
                    setLCD(4,0,"Mode: FM");
                    setCoarseFrequency(freq);
                    setPower(power, freq);
                    int k = 0;
                    for(i=3;i>=0; i--){
                        dataBinary[k] = (inputData[0]>>i) & 0x01;
                        dataBinary[k+4] = (inputData[1]>>i) & 0x01;
                        k++;
                    }
                }
                if(mode == 4){
                    setLCD(4,0,"Mode: IQ");
                    setCoarseFrequency(freq);
                    setPower(power, freq);
                }

                i = 0;
                while(state == 1){
                    long tempFreq;
                    int tempPower;
                    if(mode == 2){
                        if(dataBinary[i]==1){
                            tempPower = power-10;
                            setPower(tempPower, freq);
                        }else{
                            setPower(power, freq);
                        }
                        if(i<7){
                            i++;
                        }else{
                            i = 0;
                        }
                        DEVICE_DELAY_US(500000);
                    }
                    if(mode == 3){
                        if(dataBinary[i]==1){
                            tempFreq = freq+10000;
                            setCoarseFrequency(tempFreq);
                        }else{
                            setCoarseFrequency(freq);
                        }
                        if(i<7){
                            i++;
                        }else{
                            i = 0;
                        }
                        DEVICE_DELAY_US(500000);
                    }
                    if(newInput){
                        if (numInput == 10){
                            state = 0;
                        }

                        if (numInput == 11){
                            state = 2;
                        }
                        newInput = false;
                    }
                }
            }
            break;

            //Enter Frequency Display
            case 2:
            {
                clearLCD();
                setLCD(1,0,"Enter Freq:");
                tempcol = 0;
                int i;
                setLCD(3,18,"Hz");
                for(i = 0; i<9; i++){
                    inputFreq[i] = 0;
                    stringFreq[i] = ' ';
                }
                while(state == 2){
                    if(newInput){
                        if (numInput != 10 & numInput != 11 & tempcol < 9){
                            setLCDChar(3,tempcol,numChar);
                            inputFreq[tempcol] = numInput;
                            stringFreq[tempcol] = numChar;
                            tempcol = tempcol + 1;
                        }

                        if (numInput == 10){
                            state = 0;
                        }

                        if (numInput == 11){
                            int i;
                            long pow;
                            int k;
                            freq = 0;
                            for(i = 0; i < tempcol; i++){
                                pow = 1;
                                for(k = 1; k < tempcol - i; k++){
                                    pow = pow * 10;
                                }
                                freq = freq + pow * inputFreq[i];
                                state = 3;
                            }

                            if (freq < 1000000){
                                clearLCD();
                                setLCD(1,0,"ERROR");
                                setLCD(2,0,"Freq Range");
                                setLCD(3,0,"1MHz-500MHz");
                                DEVICE_DELAY_US(3000000);
                                freq = 100000000;
                                state = 0;
                            }

                            if (freq > 500000000){
                                clearLCD();
                                setLCD(1,0,"ERROR");
                                setLCD(2,0,"Freq Range");
                                setLCD(3,0,"1MHz-500MHz");
                                DEVICE_DELAY_US(3000000);
                                freq = 100000000;
                                state = 0;
                            }


                        }
                        newInput = false;
                    }
                }
            }
            break;
            //Enter Power Menu
            case 3:
            {
                clearLCD();
                setLCD(1,0,"Enter Power:");
                setLCD(3,17,"dBm");
                tempcol = 0;
                int i;
                for(i = 0; i<9; i++){
                    inputPower[i] = 0;
                    stringPower[i] = ' ';
                }
                while(state == 3){
                    if(newInput){
                        if (numInput != 10 & numInput != 11 & tempcol < 9){
                            setLCDChar(3,tempcol,numChar);
                            inputPower[tempcol] = numInput;
                            stringPower[tempcol] = numChar;
                            tempcol = tempcol + 1;
                        }
                        if (numInput == 10){
                            state = 0;
                        }
                        if(numInput == 11){
                            int i;
                            long pow;
                            int k;
                            power = 0;
                            for(i = 0; i < tempcol; i++){
                                pow = 1;
                                for(k = 1; k < tempcol - i; k++){
                                    pow = pow * 10;
                                }
                                power = power + pow * inputPower[i];
                            }
                            state = 4;
                        }
                        newInput = false;
                    }
                }
            }
            break;

            //Enter Data Menu
            case 4:
            {
                clearLCD();
                setLCD(1,0,"1. - Power");
                setLCD(2,0,"2. + Power");
                tempcol = 0;
                while(state == 4){
                    if(newInput){
                        if (numInput == 1){
                            power = power * -1;
                            setLCD(3,0,"-");
                            setLCD(3,1,stringPower);
                            if (power < -100){
                                clearLCD();
                                setLCD(1,0,"ERROR");
                                setLCD(2,0,"Power Range");
                                setLCD(3,0,"-100dBm-10dBm");
                                DEVICE_DELAY_US(3000000);
                                power = 0;
                                state = 0;
                            }
                        }
                        if (numInput == 2){
                            power = power * 1;
                            setLCD(3,0,"+");
                            setLCD(3,1,stringPower);
                            if (power > 10){
                                clearLCD();
                                setLCD(1,0,"ERROR");
                                setLCD(2,0,"Power Range");
                                setLCD(3,0,"-100dBm-10dBm");
                                DEVICE_DELAY_US(3000000);
                                power = 0;
                                state = 0;
                            }
                        }
                        if (numInput == 10){
                            state = 0;
                        }
                        if(numInput == 11){
                            if(mode == 1){
                                state = 1;
                            }
                            if(mode == 2){
                                state = 5;
                            }
                            if(mode == 3){
                                state = 5;
                            }
                            if(mode == 4){
                                state = 1;
                            }
                        }
                        newInput = false;
                    }
                }
            }

            case 5:
            {
                clearLCD();
                setLCD(1,0,"Enter Data:");
                tempcol = 0;
                int i = 0;
                for(i = 0; i<9; i++){
                    inputData[i] = 0;
                }
                while(state == 5){
                    if(newInput){
                        if (numInput != 10 & numInput != 11 & tempcol < 9){
                            setLCDChar(3,tempcol,numChar);
                            inputData[tempcol] = numInput;
                            tempcol = tempcol + 1;
                        }
                        if (numInput == 10){
                            state = 0;
                        }
                        if(numInput == 11){
                            state = 1;
                        }
                        newInput = false;
                    }
                }
            }
            break;
        }

    }
}

long calFreq(long freq){
    long newOffsetFreq = (long) (offsetFreq + (float) (0.0000015*(freq-10000000)));
    return newOffsetFreq; //offsetFreq should be added to desired frequency
}

//Clears the LCD screen and sets cursor to row1, col1
void clearLCD(){
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = LCD_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = '|'; //Puts LCD screen into settings mode " | "
    i2cMsgOut.msgBuffer[1] = '-'; //Sends clear display command " - "
    sendIt();

}

void setLCD(int row, int col, char *text){
    int i;

    //row 1: 0
    //row 2: 64
    //row 3: 20
    //row 4: 84
    if(row == 1){
        row = 0;
    }else if (row == 2){
        row = 64;
    }else if (row == 3){
        row = 20;
    }else if(row == 4){
        row = 84;
    }else{
        row = 1;
    }
    if(col > 19){
        col = 0;
    }

    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = LCD_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = 0xFE; //Puts LCD screen into settings mode " | "
    i2cMsgOut.msgBuffer[1] = 128 + row + col;

    for(i=0; text[i] != '\0'; i++)
       {
        i2cMsgOut.numBytes = i+3;
        i2cMsgOut.msgBuffer[i+2] = text[i];
       }
    sendIt();
}

void setLCDChar(int row, int col, char c){
    if(row == 1){
        row = 0;
    }else if (row == 2){
        row = 64;
    }else if (row == 3){
        row = 20;
    }else if(row == 4){
        row = 84;
    }else{
        row = 1;
    }
    if(col > 19){
        col = 0;
    }

    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = LCD_ADDR;
    i2cMsgOut.numBytes = 3;
    i2cMsgOut.msgBuffer[0] = 0xFE;
    i2cMsgOut.msgBuffer[1] = 128 + row + col;
    i2cMsgOut.msgBuffer[2] = c;
    sendIt();
}

void setupLaunchPad(){
    //uint16_t error;
    uint16_t i;
    // Initialize device clock and peripherals
    Device_init();
    // Disable pin locks and enable internal pullups.
    Device_initGPIO();
    // Initialize PIE and clear PIE registers. Disable CPU interrupts.
    Interrupt_initModule();
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    Interrupt_initVectorTable();


    //Initialize numpad pins
    //Pin 6 corresponds to column 2
    //GPIO_setPinConfig(GPIO_6_GPIO6); //Set pin as GPIO
    GPIO_setPadConfig(6, GPIO_PIN_TYPE_STD); //Set pin as push/pull output
    GPIO_setDirectionMode(6, GPIO_DIR_MODE_OUT); //Set pin direction as output
    //Pin 8 corresponds to column 1
    //GPIO_setPinConfig(GPIO_8_GPIO8); //Set pin as GPIO
    GPIO_setPadConfig(8, GPIO_PIN_TYPE_STD); //Set pin as push/pull output
    GPIO_setDirectionMode(8, GPIO_DIR_MODE_OUT); //Set pin direction as output
    //Pin 10 corresponds to column 3
    //GPIO_setPinConfig(GPIO_10_GPIO10); //Set pin as GPIO
    GPIO_setPadConfig(10, GPIO_PIN_TYPE_STD); //Set pin as push/pull output
    GPIO_setDirectionMode(10, GPIO_DIR_MODE_OUT); //Set pin direction as output

    GPIO_writePin(6,0);
    GPIO_writePin(8,0);
    GPIO_writePin(10,0);

    //Pin 7 corresponds with row 1
    GPIO_setQualificationMode(7, GPIO_QUAL_ASYNC); //Don't wait for system clock to trigger interrupt
    GPIO_setInterruptPin(7, GPIO_INT_XINT1); //Set pin to interrupt on external interrupt group 1
    //Pin 9 corresponds with row 4
    GPIO_setQualificationMode(9, GPIO_QUAL_ASYNC); //Don't wait for system clock to trigger interrupt
    GPIO_setInterruptPin(9, GPIO_INT_XINT4); //Set pin to interrupt on external interrupt group 4
    //Pin 11 corresponds with row 3
    GPIO_setQualificationMode(11, GPIO_QUAL_ASYNC); //Don't wait for system clock to trigger interrupt
    GPIO_setInterruptPin(11, GPIO_INT_XINT3); //Set pin to interrupt on external interrupt group 3
    //Pin 14 corresponds with row 2
    GPIO_setQualificationMode(14, GPIO_QUAL_ASYNC); //Don't wait for system clock to trigger interrupt
    GPIO_setInterruptPin(14, GPIO_INT_XINT2); //Set pin to interrupt on external interrupt group 2

    // Initialize GPIOs 104 and 105 for use as SDA A and SCL A respectively
    GPIO_setPinConfig(GPIO_104_SDAA);
    GPIO_setPadConfig(104, GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(104, GPIO_QUAL_ASYNC);

    GPIO_setPinConfig(GPIO_105_SCLA);
    GPIO_setPadConfig(105, GPIO_PIN_TYPE_PULLUP);
    GPIO_setQualificationMode(105, GPIO_QUAL_ASYNC);

    // Set I2C use, initializing it for FIFO mode
    initI2C();
    // Clear incoming message buffer
    for (i = 0; i < MAX_BUFFER_SIZE; i++)
    {
        i2cMsgIn.msgBuffer[i] = 0x0000;
    }
    // Set message pointer used in interrupt to point to outgoing message
    currentMsgPtr = &i2cMsgOut;

    //Set up interrupts and interupt groups
    // Interrupts are re-mapped to ISR functions found within this file.

    //Enable interrupts for GPIO pins
    GPIO_setInterruptType(GPIO_INT_XINT1, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT1);
    Interrupt_register(INT_XINT1, &XINT1Handler);
    Interrupt_enable(INT_XINT1);

    GPIO_setInterruptType(GPIO_INT_XINT2, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT2);
    Interrupt_register(INT_XINT2, &XINT2Handler);
    Interrupt_enable(INT_XINT2);

    GPIO_setInterruptType(GPIO_INT_XINT3, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT3);
    Interrupt_register(INT_XINT3, &XINT3Handler);
    Interrupt_enable(INT_XINT3);

    GPIO_setInterruptType(GPIO_INT_XINT4, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_enableInterrupt(GPIO_INT_XINT4);
    Interrupt_register(INT_XINT4, &XINT4Handler);
    Interrupt_enable(INT_XINT4);

    // Enable interrupts required for I2CA
    Interrupt_register(INT_I2CA, &i2cAISR); //Sends I2C interrupts to the i2cAISR function below
    Interrupt_enable(INT_I2CA);

    // Enables CPU interrupts
    Interrupt_enableMaster();

    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    EINT;
    ERTM;
}

void setupSi570(){
    Fout = 99999675;
    Fxtal = 100e6;

    writeSi570Reg(135, 0x80); //Resets the Si570
    DEVICE_DELAY_US(100000); //wait 100ms
    writeSi570Reg(135, 0x00); //lock changes
    read570Regs();
    r = (double) RFREQ / (268435456.0); // divide RFREQ by 2^28 (converting to double
    double hsdiv = HS_DIV + 4;  // HS_DIV is stored as 0xbbb the actual divider value is 0xbbb + 4
    double n = N1 + 1; // N1 stored as the actual divider value -1 (add one to recover divider value)
    Fdco = Fout*hsdiv*n;
    Fxtal = (Fdco / r);
}

void writeSi570Reg(int reg, int val){
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = Si570_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = reg;
    i2cMsgOut.msgBuffer[1] = val;
    sendIt();
}

//Read registers 13-18 to find RFREQ, HS_DIV and N1
void read570Regs(){
    int i;
    for(i = 7; i<13; i++){
        i2cMsgIn.msgStatus = MSG_STATUS_SEND_NOSTOP;
        i2cMsgIn.slaveAddr = Si570_ADDR;
        i2cMsgIn.numBytes = 1;
        i2cMsgIn.msgBuffer[0] = i;
        readIt();
        allRegs[i] = i2cMsgIn.msgBuffer[0];
    }

    HS_DIV = allRegs[7] >> 5; //Get the 3 MSBs from register 7
    N1 = ((allRegs[7] & 0x1F) << 2) + (allRegs[8] >> 6); //Get 5 LSBs from reg 7 and add 2 MSBs from reg 8
    RFREQ = (allRegs[8] & 0x3F); //Get 5 LSBs from reg 8
    RFREQ = (RFREQ<<8) + allRegs[9]; //Shift previous bits up and add bits from reg 9
    RFREQ = (RFREQ<<8) + allRegs[10]; //Shift previous bits up and add bits from reg 10
    RFREQ = (RFREQ<<8) + allRegs[11]; //Shift previous bits up and add bits from reg 11
    RFREQ = (RFREQ<<8) + allRegs[12]; //Shift previous bits up and add bits from reg 12
}

void set570Regs(int hsdiv, long n1, long long rfreq){
    int i;
    allRegs[7] = (uint8_t)(hsdiv << 5) + (n1 >> 2);
    allRegs[8] = (uint8_t)((n1 & 0x03) << 6) + (unsigned char)((rfreq >> 32) & 0x3f);
    allRegs[9] = (uint8_t)((rfreq >> 24) & 0xff);
    allRegs[10] = (uint8_t)((rfreq >> 16) & 0xff);
    allRegs[11] = (uint8_t)((rfreq >> 8) & 0xff);
    allRegs[12] = (uint8_t)((rfreq >> 0) & 0xff);

    for(i=7; i<13; i++){
        writeSi570Reg(i, allRegs[i]);
    }
    HS_DIV = hsdiv;
    N1 = n1;
    RFREQ = rfreq;
}

//Set the frequency of the Si570 using coarse adjust
//Note: This will temporarily stop the output when updating registers unlike a fine adjustment
void setCoarseFrequency(long f){
    //Configure Amplifier/Filter/Attenuator MCP devices for frequency ranges
    setMCP(FILT1_MCP_ADDR, 0x00);
    setMCP(FILT2_MCP_ADDR, 0x00);
    setMCP(FILT3_MCP_ADDR, 0x00);
    if(f<=2000000){
        setMCP(FILT1_MCP_ADDR, 0x01);//1-2MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB1);
        setMCP(ATT2_MCP_ADDR, 0x01);
    }else if(f<=4000000){
        setMCP(FILT1_MCP_ADDR, 0x02);//2-4MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB1);
        setMCP(ATT2_MCP_ADDR, 0x01);
    }else if(f<=8000000){
        setMCP(FILT1_MCP_ADDR, 0x04);//4-8MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB1);
        setMCP(ATT2_MCP_ADDR, 0x01);
    }else if(f<=16000000){
        setMCP(FILT2_MCP_ADDR, 0x01);//8-16MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB2);
        setMCP(ATT2_MCP_ADDR, 0x02);
    }else if(f<=32000000){
        setMCP(FILT2_MCP_ADDR, 0x02);//16-32MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB2);
        setMCP(ATT2_MCP_ADDR, 0x02);
    }else if(f<=64000000){
        setMCP(FILT3_MCP_ADDR, 0x01);//32-64MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB3);
        setMCP(ATT2_MCP_ADDR, 0x04);
    }else if(f<=128000000){
        setMCP(FILT3_MCP_ADDR, 0x02);//64-128MHz Band
        setMCP(AMP_MCP_ADDR, amp_FB3);
        setMCP(ATT2_MCP_ADDR, 0x04);
    }else if(f<=256000000){
        setMCP(FILT3_MCP_ADDR, 0x04);//128-256MHz Band - NOT WORKING
        setMCP(AMP_MCP_ADDR, amp_FB3);
        setMCP(ATT2_MCP_ADDR, 0x04);
    }else if(f<=512000000){
        setMCP(FILT3_MCP_ADDR, 0x08);//256-512MHz Band - NOT WORKING
        setMCP(AMP_MCP_ADDR, amp_FB3);
        setMCP(ATT2_MCP_ADDR, 0x04);
    }else{
        setMCP(FILT3_MCP_ADDR, 0x02); //Default to our highest working cutoff frequency
    }

    if(mode==4){
        setMCP(SYNTH_MCP_ADDR, synth_LF);
        f = f*4;
    }else{
        //Configure Synthesizer MCP device for frequency range
        if(f>6000000){
            setMCP(SYNTH_MCP_ADDR, synth_HF);
        }else{
            setMCP(SYNTH_MCP_ADDR, synth_LF);
            f = f*16;
        }
        //Configure Doubler MCP device for frequency range
        if(f>500000000){
            setMCP(DBL_MCP_ADDR, dbl_VHF);
            f = f/4;
        }else if(f>250000000){
            setMCP(DBL_MCP_ADDR, dbl_HF);
            f = f/2;
        }else{
            setMCP(DBL_MCP_ADDR, dbl_LF);
        }
    }

    f = f + calFreq(f);
    Frequency = f;
    VFOBase = f;
    double div[] = { 4, 5, 6, 7, 0, 9, 0, 11 }; // allowed values for hsdiv (zero not allowed)
    int ns[8];
    double fd[8];
    double score[8];
    int hsdiv;
    int  i;
    double c = (4.85e9 + 5.67e9) / 2; // c is the middle of the allowed Fdco range (convert to constant?)
    double r = 5.67e9 / f;  // r is the maximum value of hsdiv*n1 (r=(Fdcomax/Fout = hsdiv*n1)
    int even;

    for (hsdiv = 0; hsdiv < 8; hsdiv++)
    {
        score[hsdiv] = 1e6;
        if(div[hsdiv] == 0){
            ns[hsdiv] = 0;
        }else{
            ns[hsdiv] = r / div[hsdiv]; // compute values for n1 or each allowed value of hsdiv
        }

        fd[hsdiv] = f*div[hsdiv]*ns[hsdiv]; // compute values for Fdco for each combination of hsdiv and n1
        even = ((ns[hsdiv] & 1) == 0); // n1 cannot be odd (except for 1) so exclude odd values

        if(even){
        score[hsdiv] = fabs(fd[hsdiv] - c) / c; // compute a normalized score for how close possible values for Fdco are to the middle of the allowed Fdco range
        }
    }
    for (i = --hsdiv; i >= 0; i--)
    {
        if (score[i] <1)
        {
            hsdiv = i;
            break;
        }
    }
    Fdco = f*div[hsdiv]*(ns[hsdiv]);
    double dr = (double)Fdco / Fxtal;
    long long rfreq = (long long)(dr*268435456);

    //Configure Si570
    writeSi570Reg(137, 0x10); //Freeze changes
    set570Regs(hsdiv, ns[hsdiv]-1, rfreq);
    writeSi570Reg(137, 0x00); //un-freeze changes
//    DEVICE_DELAY_US(5000);
    writeSi570Reg(135, 0x40); //lock changes - do this within 10ms of unfreezing
}

void setupMCP(){
    //This function will initialize all MCP23008 units as outputs with a
    //desired starting output configuration

    //Set up synthesizer MCP device
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = SYNTH_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(SYNTH_MCP_ADDR, synth_HF);

    //Set up doubler board MCP device
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = DBL_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(DBL_MCP_ADDR, dbl_LF);

    //Set up amplifier board MCP device
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = AMP_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(AMP_MCP_ADDR, amp_FB1);


    //Set up filter board 1 MCP device
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = FILT1_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(FILT1_MCP_ADDR, 0x04);

    //Set up filter board 2 MCP device
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = FILT2_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(FILT2_MCP_ADDR, 0x00);

    //Set up filter board 3 MCP device
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = FILT3_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(FILT3_MCP_ADDR, 0x02);

    //Set up attenuator MCP devices
    //ATT1 device - selects attenuators
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = ATT1_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(ATT1_MCP_ADDR, 0x00);

    //ATT2 device - selects input
    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = ATT2_MCP_ADDR;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_IODIR;
    i2cMsgOut.msgBuffer[1] = 0x00; // make all I/O's outputs
    sendIt();

    setMCP(ATT2_MCP_ADDR, 0x04);

}

void setMCP(char address, char config){
    //This function will control the MCP23008 chips across on the I2C line
    //We use char as input data type because they are made up of 8 bits and
    //each message to the MCP23008 will use 8 bits

    i2cMsgOut.msgStatus = MSG_STATUS_SEND_WITHSTOP;
    i2cMsgOut.slaveAddr = address;
    i2cMsgOut.numBytes = 2;
    i2cMsgOut.msgBuffer[0] = MCP_OLAT;
    i2cMsgOut.msgBuffer[1] = config; //set starting output levels
    sendIt();

}

void setPower(int power, long freq){
     uint8_t config = 0x00; //The control byte that will eventually be sent to the ATT2 MCP device

     //We assume a power of 20dBm coming into the attenuator, the desired power is converted into
     //the necessary attenuation (att) to achieve that power. 'att' can be calibrated across
     //frequencies by applying an offset.
     int i = (int) (freq/1000000); //convert Hz into MHz - i.e. 1MHz represented as '1'
     int offset = calTable[i];

     //For example, at 100MHz, input power is 18dBm, not 20dBm.
     //Let att = att - 2dBm, where 2dBm is the offset
     uint8_t att = 20-power;
     att = att-offset;
//     if(att>50){
//         config = config | 0x40;
//         att = att-50;
//     }
     if(att>32){
         config = config | 0x20;
         att = att-32;
     }
     if(att>16){
         config = config | 0x10;
         att = att-16;
     }
     if(att>8){
         config = config | 0x08;
         att = att-8;
     }
     if(att>4){
         config = config | 0x04;
         att = att-4;
     }
     if(att>2){
         config = config | 0x02;
         att = att-2;
     }
     if(att>1){
         config = config | 0x01;
         att = att-1;
     }
     if(fineCalTable[i]==1){
         config = config | 0x80;
     }

     setMCP(ATT1_MCP_ADDR, config);
}

// This function initiates transmission of i2cMsgOut.msgBuffer to the I2c
void sendIt()
{
    uint16_t error;

    //
    // **** Write data to I2C ****
    //
    // Check the outgoing message to see if it should be sent. In this
    // example it is initialized to send with a stop bit.
    //
    if(i2cMsgOut.msgStatus == MSG_STATUS_SEND_WITHSTOP)
    {
        //
        // Send the data to the I2C line
        //
        if(I2CB == false){
            error = writeDataA(&i2cMsgOut);
        }
        //
        // If communication is correctly initiated, set msg status to busy
        // and update currentMsgPtr for the interrupt service routine.
        // Otherwise, do nothing and try again next loop. Once message is
        // initiated, the I2C interrupts will handle the rest. See the
        // function i2cAISR().
        //
        if(error == SUCCESS)
        {
            currentMsgPtr = &i2cMsgOut;
            i2cMsgOut.msgStatus = MSG_STATUS_WRITE_BUSY;
        }
    }
    DEVICE_DELAY_US(3000);

}

//
// writeData - Function to send the data that is to be written to the EEPROM
//
uint16_t writeDataA(struct I2CMsg *msg)
{
    uint16_t i;

    //
    // Wait until the STP bit is cleared from any previous master
    // communication. Clearing of this bit by the module is delayed until after
    // the SCD bit is set. If this bit is not checked prior to initiating a new
    // message, the I2C could get confused.
    //
    if(I2C_getStopConditionStatus(I2CA_BASE))
    {
        return(ERROR_STOP_NOT_READY);
    }

    //
    // Setup slave address
    //
    I2C_setSlaveAddress(I2CA_BASE, msg->slaveAddr);

    //
    // Check if bus busy
    //
    if(I2C_isBusBusy(I2CA_BASE))
    {
        return(ERROR_BUS_BUSY);
    }

    //
    // Setup number of bytes to send msgBuffer and address
    //
    I2C_setDataCount(I2CA_BASE, (msg->numBytes));

    //
    // Setup data to send
    //
    for (i = 0; i < msg->numBytes; i++)
    {
        I2C_putData(I2CA_BASE, msg->msgBuffer[i]);
    }

    //
    // Send start as master transmitter
    //
    I2C_setConfig(I2CA_BASE, I2C_MASTER_SEND_MODE);
    I2C_sendStartCondition(I2CA_BASE);
    I2C_sendStopCondition(I2CA_BASE);

    return(SUCCESS);
}

// This function initiates transmission/reception of i2cMsgIn.msgBuffer to the I2c
void readIt(){
            //
            // Check outgoing message status. Bypass read section if status is
            // not inactive.
            //
            if (i2cMsgOut.msgStatus == MSG_STATUS_INACTIVE)
            {
                //
                // Check incoming message status
                //
                if(i2cMsgIn.msgStatus == MSG_STATUS_SEND_NOSTOP)
                {
                    //
                    // Send the device register address setup
                    //
                    readData(&i2cMsgIn);

                    //
                    // Update current message pointer and message status
                    //
                    currentMsgPtr = &i2cMsgIn;
                    i2cMsgIn.msgStatus = MSG_STATUS_SEND_NOSTOP_BUSY;
                }

                DEVICE_DELAY_US(50000);
                //
                // Once message has progressed past setting up the internal address
                // of the EEPROM, send a restart to read the data bytes from the
                // EEPROM. Complete the communique with a stop bit. msgStatus is
                // updated in the interrupt service routine.
                //
                if(i2cMsgIn.msgStatus == MSG_STATUS_RESTART)
                {
                    //
                    // Read data portion
                    //
                    readData(&i2cMsgIn);

                    //
                    // Update current message pointer and message status
                    //
                    currentMsgPtr = &i2cMsgIn;
                    i2cMsgIn.msgStatus = MSG_STATUS_READ_BUSY;
                }
            }
            DEVICE_DELAY_US(50000);
}

// readData - Function to prepare for the data that is to be read from the EEPROM
uint16_t readData(struct I2CMsg *msg)
{
    //
    // Wait until the STP bit is cleared from any previous master
    // communication. Clearing of this bit by the module is delayed until after
    // the SCD bit is set. If this bit is not checked prior to initiating a new
    // message, the I2C could get confused.
    //
    if(I2C_getStopConditionStatus(I2CA_BASE))
    {
        return(ERROR_STOP_NOT_READY);
    }

    //
    // Setup slave address
    //
    I2C_setSlaveAddress(I2CA_BASE, msg->slaveAddr);

    //
    // If we are in the the address setup phase, send the address without a
    // stop condition.
    //
    if(msg->msgStatus == MSG_STATUS_SEND_NOSTOP)
    {
        //
        // Check if bus busy
        //
        if(I2C_isBusBusy(I2CA_BASE))
        {
            return(ERROR_BUS_BUSY);
        }

        //
        // Send data to setup register address
        //
        I2C_setDataCount(I2CA_BASE, 1); //We are expecting to read 1 byte
        I2C_putData(I2CA_BASE, msg->msgBuffer[0]); //This sends out the register address i.e. OLAT address for MCP23008
        I2C_setConfig(I2CA_BASE, I2C_MASTER_SEND_MODE);
        I2C_sendStartCondition(I2CA_BASE);
    }
    else if(msg->msgStatus == MSG_STATUS_RESTART)
    {
        //
        // Address setup phase has completed. Now setup how many bytes expected
        // and send restart as master-receiver.
        //
        I2C_setDataCount(I2CA_BASE, (msg->numBytes));
        I2C_setConfig(I2CA_BASE, I2C_MASTER_RECEIVE_MODE);
        I2C_sendStartCondition(I2CA_BASE);
        I2C_sendStopCondition(I2CA_BASE);
    }

    return(SUCCESS);
}

// initI2C - Function to configure I2C A in FIFO mode.
void initI2C()
{
    //Enable I2CA///////////////////////////////////////////////////////////

    // Must put I2C into reset before configuring it
    //
    I2C_disableModule(I2CA_BASE);

    //
    // I2C configuration. Use a 400kHz I2CCLK with a 33% duty cycle.
    //
    I2C_initMaster(I2CA_BASE, DEVICE_SYSCLK_FREQ, 100000, I2C_DUTYCYCLE_33);
    I2C_setBitCount(I2CA_BASE, I2C_BITCOUNT_8);
    I2C_setSlaveAddress(I2CA_BASE, SLAVE_ADDRESS);
    I2C_setEmulationMode(I2CA_BASE, I2C_EMULATION_FREE_RUN);

    //
    // Enable stop condition and register-access-ready interrupts
    //
    I2C_enableInterrupt(I2CA_BASE, I2C_INT_STOP_CONDITION |
                        I2C_INT_REG_ACCESS_RDY);

    //
    // FIFO configuration
    //
    I2C_enableFIFO(I2CA_BASE);
    I2C_clearInterruptStatus(I2CA_BASE, I2C_INT_RXFF | I2C_INT_TXFF);

    //
    // Configuration complete. Enable the module.
    //
    I2C_enableModule(I2CA_BASE);

    //Enable I2CB/////////////////////////////////////////////////////////////
    // Must put I2C into reset before configuring it
    //
    I2C_disableModule(I2CB_BASE);

    //
    // I2C configuration. Use a 400kHz I2CCLK with a 33% duty cycle.
    //
    I2C_initMaster(I2CB_BASE, DEVICE_SYSCLK_FREQ, 100000, I2C_DUTYCYCLE_33);
    I2C_setBitCount(I2CB_BASE, I2C_BITCOUNT_8);
    I2C_setSlaveAddress(I2CB_BASE, SLAVE_ADDRESS);
    I2C_setEmulationMode(I2CB_BASE, I2C_EMULATION_FREE_RUN);

    //
    // Enable stop condition and register-access-ready interrupts
    //
    I2C_enableInterrupt(I2CB_BASE, I2C_INT_STOP_CONDITION |
                        I2C_INT_REG_ACCESS_RDY);

    //
    // FIFO configuration
    //
    I2C_enableFIFO(I2CB_BASE);
    I2C_clearInterruptStatus(I2CB_BASE, I2C_INT_RXFF | I2C_INT_TXFF);

    //
    // Configuration complete. Enable the module.
    //
    I2C_enableModule(I2CB_BASE);
}

//Interrupt handlers for the numpad input
__interrupt void XINT1Handler(void){
    count++;
    rowNum = 1;

    GPIO_writePin(6,0);
    GPIO_writePin(8,1);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(7);
    if(coltest == 0){
        colNum = 2;
        numInput = 2;
        numChar = '2';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,0);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(7);
    if(coltest == 0){
        colNum = 1;
        numInput = 1;
        numChar = '1';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,1);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(7);
    if(coltest == 0){
        colNum = 3;
        numInput = 3;
        numChar = '3';
        newInput = true;
    }

    GPIO_writePin(6,0);
    GPIO_writePin(8,0);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(20000);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
__interrupt void XINT2Handler(void){
    count++;
    rowNum = 2;

    GPIO_writePin(6,0);
    GPIO_writePin(8,1);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(14);
    if(coltest == 0){
        colNum = 2;
        numInput = 5;
        numChar = '5';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,0);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(14);
    if(coltest == 0){
        colNum = 1;
        numInput = 4;
        numChar = '4';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,1);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(14);
    if(coltest == 0){
        colNum = 3;
        numInput = 6;
        numChar = '6';
        newInput = true;
    }

    GPIO_writePin(6,0);
    GPIO_writePin(8,0);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(20000);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}
__interrupt void XINT3Handler(void){
    count++;
    rowNum = 3;

    GPIO_writePin(6,0);
    GPIO_writePin(8,1);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(11);
    if(coltest == 0){
        colNum = 2;
        numInput = 8;
        numChar = '8';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,0);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(11);
    if(coltest == 0){
        colNum = 1;
        numInput = 7;
        numChar = '7';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,1);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(11);
    if(coltest == 0){
        colNum = 3;
        numInput = 9;
        numChar = '9';
        newInput = true;
    }

    GPIO_writePin(6,0);
    GPIO_writePin(8,0);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(20000);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);
}
__interrupt void XINT4Handler(void){
    count++;
    rowNum = 4;

    GPIO_writePin(6,0);
    GPIO_writePin(8,1);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(9);
    if(coltest == 0){
        colNum = 2;
        numInput = 0;
        numChar = '0';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,0);
    GPIO_writePin(10,1);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(9);
    if(coltest == 0){
        colNum = 1;
        numInput = 10;
        numChar = '*';
        newInput = true;
    }

    GPIO_writePin(6,1);
    GPIO_writePin(8,1);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(2000);
    coltest = GPIO_readPin(9);
    if(coltest == 0){
        colNum = 3;
        numInput = 11;
        numChar = '#';
        newInput = true;
    }

    GPIO_writePin(6,0);
    GPIO_writePin(8,0);
    GPIO_writePin(10,0);
    DEVICE_DELAY_US(20000);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);
}

// i2cAISR - I2C A ISR (non-FIFO)
__interrupt void i2cAISR(void)
{
    I2C_InterruptSource intSource;
    uint16_t i;

    //
    // Read interrupt source
    //
    intSource = I2C_getInterruptSource(I2CA_BASE);

    //
    // Interrupt source = stop condition detected
    //
    if(intSource == I2C_INTSRC_STOP_CONDITION)
    {
        //
        // If completed message was writing data, reset msg to inactive state
        //
        if(currentMsgPtr->msgStatus == MSG_STATUS_WRITE_BUSY)
        {
            currentMsgPtr->msgStatus = MSG_STATUS_INACTIVE;
        }
        else
        {
            //
            // If completed message was reading device data, reset message to
            // inactive state and read data from FIFO.
            //
            if(currentMsgPtr->msgStatus == MSG_STATUS_READ_BUSY)
            {
                currentMsgPtr->msgStatus = MSG_STATUS_INACTIVE;
                for(i=0; i < currentMsgPtr->numBytes; i++)
                {
                    currentMsgPtr->msgBuffer[i] = I2C_getData(I2CA_BASE);
                }
            }
        }
    }
    //
    // Interrupt source = Register Access Ready
    //
    // This interrupt is used to determine when the device register address setup
    // portion of a read data communication is complete. Since no stop bit
    // is commanded, this flag tells us when the message has been sent
    // instead of the SCD flag.
    //
    else if(intSource == I2C_INTSRC_REG_ACCESS_RDY)
    {
        //
        // If a NACK is received, clear the NACK bit and command a stop.
        // Otherwise, move on to the read data portion of the communication.
        //
        if((I2C_getStatus(I2CA_BASE) & I2C_STS_NO_ACK) != 0)
        {
            I2C_sendStopCondition(I2CA_BASE);
            I2C_clearStatus(I2CA_BASE, I2C_STS_NO_ACK);
        }
        else if(currentMsgPtr->msgStatus == MSG_STATUS_SEND_NOSTOP_BUSY)
        {
            currentMsgPtr->msgStatus = MSG_STATUS_RESTART;
        }
    }
    else
    {
        //
        // Generate some error from invalid interrupt source
        //
        asm("   ESTOP0");
    }

    //
    // Issue ACK to enable future group 8 interrupts
    //
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP8);
}

void setupCal(){
    int i;
    for(i=0; i<200; i++){
        calTable[i] = 0;
        fineCalTable[i] = 0;
    }
    calTable[3] = 1;
    fineCalTable[3] = 0;
    calTable[4] = 9;
    fineCalTable[4] = 1;
    calTable[5] = 1;
    fineCalTable[5] = 1;
    calTable[6] = 3;
    fineCalTable[6] = 1;
    calTable[8] = 9;
    fineCalTable[8] = 0;
    calTable[9] = -3;
    fineCalTable[9] = 1;
    calTable[10] = -3;
    fineCalTable[10] = 0;
    calTable[11] = -2;
    fineCalTable[11] = 1;
    calTable[12] = -1;
    fineCalTable[12] = 1;
    calTable[13] = 0;
    fineCalTable[13] = 1;
    calTable[14] = 1;
    fineCalTable[14] = 1;
    calTable[15] = 2;
    fineCalTable[15] = 0;
    calTable[16] = 4;
    fineCalTable[16] = 0;
    calTable[17] = -4;
    fineCalTable[17] = 0;
    calTable[18] = -4;
    fineCalTable[18] = 0;
    calTable[19] = -4;
    fineCalTable[19] = 0;
    calTable[20] = -4;
    fineCalTable[20] = 0;
    calTable[21] = -4;
    fineCalTable[21] = 0;
    calTable[22] = -4;
    fineCalTable[22] = 0;
    calTable[23] = -4;
    fineCalTable[23] = 0;
    calTable[24] = -3;
    fineCalTable[24] = 1;
    calTable[25] = -3;
    fineCalTable[25] = 0;
    calTable[26] = -2;
    fineCalTable[26] = 1;
    calTable[27] = -2;
    fineCalTable[27] = 0;
    calTable[28] = -1;
    fineCalTable[28] = 1;
    calTable[29] = 0;
    fineCalTable[29] = 1;
    calTable[30] = 0;
    fineCalTable[30] = 0;
    calTable[31] = 1;
    fineCalTable[31] = 0;
    calTable[32] = 2;
    fineCalTable[32] = 0;
    calTable[33] = -4;
    fineCalTable[33] = 1;
    calTable[34] = -4;
    fineCalTable[34] = 0;
    calTable[35] = -4;
    fineCalTable[35] = 0;
    calTable[36] = -4;
    fineCalTable[36] = 0;
    calTable[37] = -3;
    fineCalTable[37] = 1;
    calTable[38] = -3;
    fineCalTable[38] = 1;
    calTable[39] = -3;
    fineCalTable[39] = 1;
    calTable[40] = -3;
    fineCalTable[40] = 1;
    calTable[41] = -3;
    fineCalTable[41] = 0;
    calTable[42] = -3;
    fineCalTable[42] = 0;
    calTable[43] = -3;
    fineCalTable[43] = 0;
    calTable[44] = -3;
    fineCalTable[44] = 0;
    calTable[45] = -2;
    fineCalTable[45] = 1;
    calTable[46] = -2;
    fineCalTable[46] = 0;
    calTable[47] = -2;
    fineCalTable[47] = 0;
    calTable[48] = -1;
    fineCalTable[48] = 1;
    calTable[49] = -1;
    fineCalTable[49] = 0;
    calTable[50] = 0;
    fineCalTable[50] = 1;
    calTable[51] = 0;
    fineCalTable[51] = 1;
    calTable[52] = 0;
    fineCalTable[52] = 0;
    calTable[53] = 0;
    fineCalTable[53] = 0;
    calTable[54] = 1;
    fineCalTable[54] = 1;
    calTable[55] = 1;
    fineCalTable[55] = 1;
    calTable[56] = 1;
    fineCalTable[56] = 0;
    calTable[57] = 1;
    fineCalTable[57] = 0;
    calTable[58] = 2;
    fineCalTable[58] = 1;
    calTable[59] = 2;
    fineCalTable[59] = 0;
    calTable[60] = 2;
    fineCalTable[60] = 0;
    calTable[61] = 3;
    fineCalTable[61] = 1;
    calTable[62] = 3;
    fineCalTable[62] = 0;
    calTable[63] = 4;
    fineCalTable[63] = 1;
    calTable[64] = 4;
    fineCalTable[64] = 0;
    for(i=65; i<=77; i++){
            calTable[i] = -5;
            fineCalTable[i] = 0;
    }
//    calTable[65] = -5;
//    fineCalTable[65] = 0;
//    calTable[66] = -5;
//    fineCalTable[66] = 0;
//    calTable[67] = -5;
//    fineCalTable[67] = 0;
//    calTable[68] = -5;
//    fineCalTable[68] = 0;
//    calTable[69] = -5;
//    fineCalTable[69] = 0;
//    calTable[70] = -5;
//    fineCalTable[70] = 0;
//    calTable[71] = -5;
//    fineCalTable[71] = 0;
//    calTable[72] = -5;
//    fineCalTable[72] = 0;
//    calTable[73] = -5;
//    fineCalTable[73] = 0;
//    calTable[74] = -5;
//    fineCalTable[74] = 0;
//    calTable[75] = -5;
//    fineCalTable[75] = 0;
//    calTable[76] = -5;
//    fineCalTable[76] = 0;
//    calTable[77] = -5;
//    fineCalTable[77] = 0;

    for(i=78; i<=83; i++){
            calTable[i] = -4;
            fineCalTable[i] = 0;
    }
//    calTable[78] = -4;
//    fineCalTable[78] = 0;
//    calTable[79] = -4;
//    fineCalTable[79] = 1;
//    calTable[80] = -4;
//    fineCalTable[80] = 1;
//    calTable[81] = -4;
//    fineCalTable[81] = 0;
//    calTable[82] = -4;
//    fineCalTable[82] = 0;
//    calTable[83] = -4;
//    fineCalTable[83] = 0;

    calTable[84] = -3;
    fineCalTable[84] = 0;
    calTable[85] = -3;
    fineCalTable[85] = 0;
    calTable[86] = -3;
    fineCalTable[86] = 0;

    calTable[87] = -2;
    fineCalTable[87] = 1;
    calTable[88] = -2;
    fineCalTable[88] = 1;
    calTable[89] = -2;
    fineCalTable[89] = 0;
    calTable[90] = -2;
    fineCalTable[90] = 0;

    calTable[91] = -1;
    fineCalTable[91] = 1;
    calTable[92] = -1;
    fineCalTable[92] = 0;
    calTable[93] = -1;
    fineCalTable[93] = 0;

//    calTable[94] = 0;
//    fineCalTable[94] = 1;
//    calTable[95] = 0;
//    fineCalTable[95] = 1;
//    calTable[96] = 0;
//    fineCalTable[96] = 0;
//    calTable[97] = 0;
//    fineCalTable[97] = 0;
//    calTable[98] = 0;
//    fineCalTable[98] = 0;
//    calTable[99] = 0;
//    fineCalTable[99] = 0;

    calTable[100] = 1;
    fineCalTable[100] = 1;
    calTable[101] = 1;
    fineCalTable[101] = 0;
    calTable[102] = 1;
    fineCalTable[102] = 0;
    calTable[103] = 1;
    fineCalTable[103] = 0;

    for(i=104; i<=110; i++){
            calTable[i] = 2;
            fineCalTable[i] = 0;
    }
//    calTable[104] = 2;
//    fineCalTable[104] = 0;
//    calTable[105] = 2;
//    fineCalTable[105] = 0;
//    calTable[106] = 2;
//    fineCalTable[106] = 0;
//    calTable[107] = 2;
//    fineCalTable[107] = 0;
//    calTable[108] = 2;
//    fineCalTable[108] = 0;
//    calTable[109] = 2;
//    fineCalTable[109] = 0;
//    calTable[110] = 2;
//    fineCalTable[110] = 0;

    for(i=111; i<=118; i++){
            calTable[i] = 3;
            fineCalTable[i] = 0;
    }
//    calTable[111] = 3;
//    fineCalTable[111] = 1;
//    calTable[112] = 3;
//    fineCalTable[112] = 1;
//    calTable[113] = 3;
//    fineCalTable[113] = 1;
//    calTable[114] = 3;
//    fineCalTable[114] = 0;
//    calTable[115] = 3;
//    fineCalTable[115] = 0;
//    calTable[116] = 3;
//    fineCalTable[116] = 0;
//    calTable[117] = 3;
//    fineCalTable[117] = 0;
//    calTable[118] = 3;
//    fineCalTable[118] = 0;

    for(i=119; i<=128; i++){
            calTable[i] = 4;
            fineCalTable[i] = 0;
        }
//    calTable[119] = 4;
//    fineCalTable[119] = 1;
//    calTable[120] = 4;
//    fineCalTable[120] = 0;
//    calTable[121] = 4;
//    fineCalTable[121] = 0;
//    calTable[122] = 4;
//    fineCalTable[122] = 0;
//    calTable[123] = 4;
//    fineCalTable[123] = 0;
//    calTable[124] = 4;
//    fineCalTable[124] = 0;
//    calTable[125] = 4;
//    fineCalTable[125] = 0;
//    calTable[126] = 4;
//    fineCalTable[126] = 0;
//    calTable[127] = 5;
//    fineCalTable[127] = 0;
//    calTable[128] = 4;
//    fineCalTable[128] = 0;
}

///////////////////////////////////////////////////////////////////////////////////
// End of File
///////////////////////////////////////////////////////////////////////////////////
