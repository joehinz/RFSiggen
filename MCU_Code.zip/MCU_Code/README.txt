MCU Code Installation/Use Instructions:

The MCU we use is the tms320f28379d on the LAUNCHXL-F28379D development board.

Code for the MCU is developed on Texas Instrument's proprietary IDE Code Composer Studio.
You will need to download this and connect your computer to the development board via a 
USB cable to build the code on the MCU. Simply Copy the "master_control" folder into your
'users/johndoe/workspaceV10/' directory. 'workspaceV10' should be a directory made by Code
Composer Studio to hold your projects. 

Note the program is quite big and will require you to optimize for size over speed in the 
build settings.
